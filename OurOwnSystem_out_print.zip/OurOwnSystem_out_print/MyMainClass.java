//3131000

//Step ->1
package dt.st2;
public class MyMainClass//PrintStream
{//                println(String s)
public static void printMyMessage(String s)
	{
		System.out.println(s);

	}
 }
//compile
	 	



	 	
	
			
			

	
















	 	// double b=Math.floor(Math.random()*10);
			// System.out.println((int)b);

			// System.out.println((int)(10*random()));




	 


	

	 
	 	
	 




















	




	






























































