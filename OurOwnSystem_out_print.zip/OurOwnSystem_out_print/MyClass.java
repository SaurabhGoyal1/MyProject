
//Step->2
package dt.st3;
import dt.st2.MyMainClass;
public class MyClass//like as System class 
{
	public static MyMainClass message;
	//            PrintStream  out

 	
 }
 //compile