import dt.st3.MyClass;
public class UseOurClass
{
	public static void main(String[] args) 
	{
		MyClass.message.printMyMessage("Hello");
	}
}