import pyttsx3
import webbrowser
import smtplib
import random
import speech_recognition as sr
import wikipedia
import datetime
import wolframalpha
import os
import sys
import dictionary 
from googletrans import Translator
import time
import matplotlib.pyplot as plt
engine = pyttsx3.init('sapi5')

client = wolframalpha.Client('Your_App_ID')

voices = engine.getProperty('voices')
engine.setProperty('voice', voices[0].id)

def speak(audio):
    engine.setProperty('rate', 200)
    print('Jarvis: ' + audio)
    engine.say(audio)
    engine.runAndWait()

def greetMe():
    hour = int(datetime.datetime.now().hour)
    if hour >= 0 and hour < 12:
        speak('Good Morning!')

    if hour >= 12 and hour < 18:
        speak('Good Afternoon!')

    if hour >= 18 and hour !=0:
        speak('Good Evening!')

greetMe()

speak('Hello Sir, I am your Jarvis!')
speak('How may I help you?')


def takecommand():
    r = sr.Recognizer()                                                                                   
    with sr.Microphone() as source:                                                                       
        print("Listening...")
        r.pause_threshold =  .5
        audio = r.listen(source)
    try:
        query = r.recognize_google(audio, language="en-US")
        print(f"User said:{query}\n")
        
    except Exception as e:
        print('try again')
        return "None" 

    return query
        

if __name__ == '__main__':

    while True:
    
        query =takecommand()
        query = query.lower()
        
        if 'open youtube' in query:
            speak('yes sir')
            webbrowser.open('www.youtube.com')
            time.sleep(2)
            speak('done it')

        elif 'open google' in query:
            speak('okay')
            webbrowser.open('www.google.co.in')
            time.sleep(2)
            speak('done it')

        elif 'open gmail' in query:
            speak('okay')
            webbrowser.open('www.gmail.com')
            time.sleep(2)
            speak('done it')

        elif "what\'s up" in query or 'how are you' in query:
            stMsgs = ['Just doing my thing!', 'I am fine!', 'Nice!', 'I am nice and full of energy',]
            speak(random.choice(stMsgs))

        elif 'email' in query:
            speak('Who is the recipient? ')
            recipient = takecommand()

            if 'me' in recipient:
                try:
                    speak('What should I say? ')
                    content = takecommand()
                    server = smtplib.SMTP('smtp.gmail.com', 587)
                    server.ehlo()
                    server.starttls()
                    server.login("Your_Username", 'Your_Password')
                    server.sendmail('Your_Username', "Recipient_Username", content)
                    server.close()
                    speak('Email sent!')

                except:
                    speak('Sorry Sir! I am unable to send your message at this moment!')


        elif 'nothing' in query or 'abort' in query or 'stop' in query or 'bye' in query:
            speak('okay')
            speak('Bye Sir, have a good day.')
            sys.exit()
           
        elif 'hello' in query:
            speak('Hello Sir')

        
        elif 'play music' in query:
            music_folder=r"D:\Data\Song"
            music = os.listdir(music_folder)
            os.startfile(os.path.join(music_folder,random.choice(music)))
            speak('Okay, here is your music! Enjoy!')
            
            
        elif 'sentence' in query:
            speak('what should say..')
            sentence=takecommand()
            
            translator=Translator()
            translated_sentence=translator.translate(sentence, src='en',dest='hi')
            print(translated_sentence.text)
            speak(translated_sentence.text)
            time.sleep(2)
            speak('done it')
        elif 'search' in  query:
            query = takecommand()
            speak('Searching...')
            try:
                try:
                    res = client.query(query)
                    results = next(res.results).text
                
                    speak('Got it.')
                    speak(results)
                    
                except:
                    results = wikipedia.summary(query, sentences=2)
                    speak('Got it.')
                    speak('WIKIPEDIA says - ')
                    speak(results)
        
            except:
                webbrowser.open('www.google.com')
        elif 'machine learning' in query:
            speak('first list')
            l=[1,2,3,4]
            speak('second list')
            l2=[1,2,5,6]
            plt.plot(l,l2)
            plt.show()
        elif 'type' in query:
            new=2
            tabUrl="http://google.com/?#q="
            typ=takecommand()
            webbrowser.open(tabUrl+typ,new=new)
        elif 'song close' in query or 'play close' in query or 'stop song' in query :
        
            os.system("TASKKILL /F /IM wmplayer.exe ")
            speak("Done")
        elif 'close google' in query or 'google close' in query or 'close chrome' in query or 'chrome close' in query :
        
            os.system("TASKKILL /F /IM Chrome.exe ")
            speak("Done")
        elif 'what is this?' in query:
            speak("what happened?, sir")
            query=takecommand()
            
        elif "imi number" in query or "phone number" in query:
            speak("pleace Note down")
            time.sleep(1)
            speak("2012065345") 
        dic={'what is current pm':"Mr.Narander Modi","what is current cm":"Mr.Yogi"}
        for i,j in dic.items():
            if query==i:
                print(dic[query])
                speak(dic[query])
            break
            
            