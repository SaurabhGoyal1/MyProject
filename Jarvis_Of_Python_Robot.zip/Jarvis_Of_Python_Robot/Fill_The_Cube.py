N=int(input())
lis=[]
for i in range(N):
    c=input()
    c.split(' ')
    maxi=c.count("C")
    lis.append(maxi)
print(max(lis))
    
    