package libraryClass;
abstract public class Library
{
abstract void btech();
abstract void polytechnic();
abstract void ba();
abstract void bsc();
}	