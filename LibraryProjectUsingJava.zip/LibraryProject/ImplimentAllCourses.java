package inSideAllCourses;
import java.util.Scanner;
import libraryClass.Library;
class ImplimentAllCourses extends Library
{
	
	void bookFirstYear()
	{
		System.out.println("1.DataBig");
		System.out.println("2.Data Structure");
		System.out.println("3.Java");
		System.out.println("4.C Language");
		
	}
	void bookSecondYear()
	{
		System.out.println("1.DataBig");
		System.out.println("2.Data Structure");
		System.out.println("3.Java");
		System.out.println("4.C Language");
		
	}
	void bookThirdYear()
	{
		System.out.println("1.DataBig");
		System.out.println("2.Data Structure");
		System.out.println("3.Java");
		System.out.println("4.C Language");
		
	}
	void bookForthYear()
	{
		System.out.println("1.DataBig");
		System.out.println("2.Data Structure");
		System.out.println("3.Java");
		System.out.println("4.C Language");
		
	}
	
	void whichYear()
	{
		System.out.println("Years");
		do{
		System.out.println("1.Ith Year");
		System.out.println("2.IInd Year");
		System.out.println("3.IIIrd Year");
		System.out.println("4.IVth Year");
		System.out.println("5.Exit Programe");
		
		System.out.println("Select Your Year..");
		Scanner sc=new Scanner(System.in);
		int ch=sc.nextInt();
		switch(ch)
		{
			case 1:
			{
				bookFirstYear();
				break;
			}
			case 2:
			{
				bookSecondYear();
				break;
			}
			case 3:
			{
				bookThirdYear();
				break;
			}
			case 4:
			{
				bookForthYear();
				break;
			}
		}}while(ch!=5);
		
			
		
		
		
	}
	void btech()
	{
		
		System.out.println("\t\tWelcome To B.Tech");
		System.out.println("Branches:");
		System.out.println("1.Computer Science(CS)");
		System.out.println("2.Macanical Engineear(ME)");
		System.out.println("3.Electronic Engineear(ECE)");
		System.out.println("4.Civil Engineear(CE)");
		System.out.println("Select Your Branch..");
		Scanner sc=new Scanner(System.in);
			
		int ch=sc.nextInt();
		if( ch==(1||2||3||4))
		{
			whichYear();
			break;
		}
		else
		{
			System.out.println("No,Match Branch Above List\nTry Again...");
			btech();
		}
			
	}
}
				
				
	
	